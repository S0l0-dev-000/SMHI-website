import os
import requests
from pathlib import Path

# Create the LED brands directory if it doesn't exist
led_brands_dir = Path("images/led-brands")
led_brands_dir.mkdir(parents=True, exist_ok=True)

def download_image(url, filename):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, stream=True)
        response.raise_for_status()
        with open(led_brands_dir / filename, 'wb') as f:
            for chunk in response.iter_content(8192):
                f.write(chunk)
        print(f"Downloaded {filename}")
    except Exception as e:
        print(f"Error downloading {url}: {e}")

# LED Brand Logos to download
brand_logos = {
    # Philips Lighting (Signify)
    "philips.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Philips_logo_new.svg/1280px-Philips_logo_new.svg.png",
    # Cree LED
    "cree.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Cree-Logo.svg/1280px-Cree-Logo.svg.png",
    # Hubbell Lighting
    "hubbell.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Hubbell_Logo.svg/2560px-Hubbell_Logo.svg.png",
    # GE Lighting
    "ge.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/General_Electric_logo.svg/1280px-General_Electric_logo.svg.png",
    # Signify (formerly Philips Lighting)
    "signify.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Signify_logo.svg/1280px-Signify_logo.svg.png",
    # Acuity Brands
    "acuity.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Acuity_Brands_logo.svg/1280px-Acuity_Brands_logo.svg.png",
    # Sylvania
    "sylvania.png": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Sylvania_logo.svg/1280px-Sylvania_logo.svg.png",
    # Cree Lighting (separate from Cree Inc.)
    "cree-lighting.png": "https://www.creelighting.com/hs-fs/hubfs/Cree%20Lighting%20-%20Logo%20-%20Horizontal%20-%20Color.png"
}

# Download all brand logos
for filename, url in brand_logos.items():
    # Skip if file already exists
    if not (led_brands_dir / filename).exists():
        download_image(url, filename)
    else:
        print(f"Skipping {filename} - already exists")
