import os
import requests
from urllib.parse import urlparse

def download_logo(url, filename):
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(1024):
                f.write(chunk)
        print(f"Downloaded: {filename}")
        return True
    except Exception as e:
        print(f"Error downloading {url}: {e}")
        return False

def main():
    # Create vfd-brands directory if it doesn't exist
    os.makedirs('images/vfd-brands', exist_ok=True)
    
    # VFD brand logos to download (using direct image URLs)
    vfd_brands = [
        {
            'url': 'https://www.abb.com/etc/designs/abb/abb-library-core/img/abb-logo.png',
            'filename': 'ABB_logo.png'
        },
        {
            'url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Siemens-logo.png/640px-Siemens-logo.png',
            'filename': 'Siemens_logo.png'
        },
        {
            'url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Rockwell_Automation_logo_2021.svg/1200px-Rockwell_Automation_logo_2021.svg.png',
            'filename': 'Rockwell_Automation_logo.png'
        },
        {
            'url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/WEG_logo.svg/1200px-WEG_logo.svg.png',
            'filename': 'WEG_logo.png'
        },
        {
            'url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Danfoss_Logo.svg/1200px-Danfoss_Logo.svg.png',
            'filename': 'Danfoss_Logo.png'
        }
    ]
    
    # Download each logo
    for brand in vfd_brands:
        output_path = os.path.join('images/vfd-brands', brand['filename'])
        if not os.path.exists(output_path):
            download_logo(brand['url'], output_path)
        else:
            print(f"File already exists: {output_path}")

if __name__ == "__main__":
    main()
