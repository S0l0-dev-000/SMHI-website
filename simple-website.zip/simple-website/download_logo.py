import requests

def download_logo(url, save_path):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, stream=True)
        response.raise_for_status()
        
        with open(save_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"Logo downloaded successfully to {save_path}")
        return True
    except Exception as e:
        print(f"Error downloading logo: {e}")
        return False

# Duke Energy logo URL (alternative source)
duke_energy_logo_url = "https://www.duke-energy.com/images/logo-duke-energy.svg"
save_path = "images/partners/duke-energy-logo.png"

download_logo(duke_energy_logo_url, save_path)
