# SMHI Energy Solutions - Website

This is the official website for SMHI Energy Solutions, a company specializing in energy efficiency solutions. The website is built with HTML, CSS, and vanilla JavaScript, making it lightweight and fast.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
- [Local Development](#local-development)
- [Building for Production](#building-for-production)
- [Deployment Options](#deployment-options)
  - [Netlify](#netlify)
  - [Vercel](#vercel)
  - [GitHub Pages](#github-pages)
  - [Traditional Web Hosting](#traditional-web-hosting)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)
- [License](#license)

## Prerequisites

Before you begin, ensure you have the following installed:
- A code editor (e.g., [VS Code](https://code.visualstudio.com/))
- [Git](https://git-scm.com/)
- [Node.js](https://nodejs.org/) (v14 or later recommended)
- [npm](https://www.npmjs.com/) (comes with Node.js)

## Getting Started

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/smhi-energy-solutions.git
   cd smhi-energy-solutions
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```
   
   > Note: If you don't need development tools, you can directly open the HTML files in a browser.

## Local Development

To run the website locally for development:

1. **Using Live Server (VS Code Extension)**
   - Install the "Live Server" extension in VS Code
   - Right-click on `index.html` and select "Open with Live Server"

2. **Using Python's built-in server**
   ```bash
   # Python 3
   python -m http.server 8000
   ```
   Then open `http://localhost:8000` in your browser

3. **Using Node.js http-server**
   ```bash
   npx http-server -p 3000
   ```
   Then open `http://localhost:3000` in your browser

## Building for Production

This is a static website, so no build step is required. However, you can optimize assets before deployment:

1. **Optimize images**
   - Run images through tools like [TinyPNG](https://tinypng.com/) or use an image optimization script

2. **Minify assets** (optional)
   ```bash
   # Install minification tools
   npm install -g html-minifier clean-css-cli uglify-js
   
   # Minify HTML
   html-minifier --collapse-whitespace --remove-comments --remove-optional-tags --remove-redundant-attributes --remove-script-type-attributes --remove-tag-whitespace --use-short-doctype -o dist/index.html index.html
   
   # Minify CSS
   cleancss -o dist/css/style.min.css css/style.css
   
   # Minify JS
   uglifyjs js/main.js -o dist/js/main.min.js --compress --mangle
   ```

## Deployment Options

### Netlify

1. Push your code to a GitHub, GitLab, or Bitbucket repository
2. Sign up/Log in to [Netlify](https://www.netlify.com/)
3. Click "New site from Git"
4. Select your repository
5. Configure build settings:
   - Build command: `npm run build` (or leave empty if no build step)
   - Publish directory: `/` (or `dist/` if you minified assets)
6. Click "Deploy site"

### Vercel

1. Push your code to a GitHub, GitLab, or Bitbucket repository
2. Sign up/Log in to [Vercel](https://vercel.com/)
3. Click "Import Project"
4. Select your repository
5. Configure project:
   - Framework Preset: Other
   - Output Directory: (leave empty or `dist` if minified)
6. Click "Deploy"

### GitHub Pages

1. Ensure your code is pushed to a GitHub repository
2. Go to your repository settings
3. Navigate to "Pages" in the left sidebar
4. Under "Source", select the `main` branch and `/` (root) folder
5. Click "Save"
6. Your site will be available at `https://[username].github.io/[repository-name]/`

### Traditional Web Hosting

1. Compress your project files (or just the `dist` folder if you minified assets)
2. Log in to your web hosting control panel (cPanel, Plesk, etc.)
3. Use the File Manager to navigate to your website's root directory (often `public_html` or `www`)
4. Upload and extract your files
5. Ensure `index.html` is in the root directory

## Environment Variables

This project doesn't require environment variables by default. However, if you add features like forms or analytics, you might need to set up environment variables with your hosting provider.

## Troubleshooting

- **Page not loading correctly?**
  - Check browser console for errors
  - Ensure all file paths are correct (case-sensitive on some servers)
  - Clear your browser cache

- **Images not showing?**
  - Verify image paths in your HTML/CSS
  - Ensure image files are uploaded
  - Check file permissions

- **Form not working?**
  - If using Netlify, ensure the form has `netlify` attribute
  - Check for JavaScript errors in the console

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

For any questions or support, please contact [your-email@example.com](mailto:your-email@example.com)
